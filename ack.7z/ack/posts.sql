--
-- 文章表
--

DROP TABLE IF EXISTS `ops_posts`;
CREATE TABLE IF NOT EXISTS `ops_posts` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '公告ID',
    `title` varchar(150) NOT NULL DEFAULT '' COMMENT '标题名',
    `content` text NOT NULL COMMENT '公告内容',
    `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态:0-不显示,1-显示',
    `sortno` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
    `addtime` int(10) unsigned NOT NULL COMMENT '创建时间',
    `uptime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
	`type`	tinyint unsigned NOT NULL DEFAULT '0' comment '类型: 1-媒体报道, 2-慈善',
    PRIMARY KEY (`id`),
    KEY `title` (`title`),
	KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

