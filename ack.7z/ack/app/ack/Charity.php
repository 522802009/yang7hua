<?php

class Ack_Action_Charity extends Ack_Action_Posts
{
	protected $_type;
	public function _initialize()
	{
		$this->_type = parent::_getType('charity');
		parent::_initialize();
	}
}
