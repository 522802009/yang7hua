<?php

class Ack_Action_Posts extends Ack_Action {
    public $publicAction = '*';

	private $type = array(
				'media'	=>	1,
				'charity'	=>	2
			);
	protected $_type = 0;

	protected function _getType($type)
	{
		if(is_numeric($type))
			return $type;
		if(is_string($type) && array_key_exists($type, $this->type))
			return $this->type[$type];
		return 0;
	}

    public function index()
    {
        $this->_list();
    }

    public function _list()
    {
        $where = array();
        $where['status'] = empty($_SESSION['aid']) ? 1 : array('gt', -1);
        $q = $this->getSearch('q');
        if ($q !== '')
            $where['title'] = array('like', '%'.$q.'%');
		if ($this->_type)
			$where['type'] = $this->_type;
		$where['status'] = 1;
        $Posts = M('posts');
        $total = $Posts->where($where)->count();
        $list = array();
        if ($total > 0) {
            $order = 'addtime desc';
            $size = 10;
            $roll = 5;
            $p = new Ops_Page($total, $size);
            $p->rollPage = $roll;
            $page = $p->getPage();
            $limit = $p->firstRow.','.$size; 
            $list = $Posts->field('id,title,addtime,uptime')->where($where)->order($order)->limit($limit)->select();
        } else {
            $list = array();
            $page = array();
        }

        $posts = array('list'=>$list);
        if ($this->isAjax()) {
            $posts['page'] = $page;
            $this->ajaxReturn($posts);
        }

        if ($q !== '')
            $page['query'] = '&q='.urlencode($q);
        $this->assign('q', $q);
        $this->assign('posts', $posts);
        $this->assign('page', $page); 

        $this->display();
    }
    
    protected function getId($key='id', $no=2)
    {
        $id = $this->getParam($key, 0);
        if (empty($id)) {
            if (isset($_GET['_URL_'][$no]))
                $id = $_GET['_URL_'][$no];
        }
        $id = intval($id);
        return $id;
    }

    public function detail()
    {
        $id = $this->getId();
        if (empty($id)) {
            if ($this->isAjax())
                $this->error('参数id不能为空');
            $this->redirect('/posts');
        }

        if (!empty($_SESSION['aid']))
            $status = array('gt', -1);
        else
            $status = 1;

        $posts = M('posts')->where(array('id'=>$id,'status'=>$status))->find();
        if (empty($posts)) {
            if ($this->isAjax())
                $this->error('记录不存在');
            $this->redirect('/posts');
        }

        if ($this->isAjax()) {
            $this->ajaxReturn($posts);
        }

        $this->assign('posts', $posts);
        $this->display();
    }
}

