<?php

class Ack_Action_Media extends Ack_Action_Posts
{
	protected $_type;
	public function _initialize()
	{
		$this->_type = parent::_getType('media');
		parent::_initialize();
	}
}
