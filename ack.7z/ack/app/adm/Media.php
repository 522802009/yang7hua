<?php

class Adm_Action_Media extends Adm_Action_Posts{
	
	protected $_type;

	public function _initialize()
	{
		$this->_type = parent::_getType('media');	
		parent::_initialize();
	}

}

