<?php

class Adm_Action_Posts extends Adm_Action {
    public $table	=	'posts';
	
	private $type	=	array(
				'media'		=>	1,
				'charity'	=>	2
			);
	protected $_type =	0;

	protected function _getType($type)
	{
		if(is_numeric($type))
			return intval($type);
		if(is_string($type) && array_key_exists($type, $this->type))
			return $this->type[$type];
		return 0;
	}

    public function _list()
    {
        if ($this->isAjax()) {
            $where = array();
            $keyword = $_POST['key'];
			$type = $this->_type;
            if (!empty($keyword))
                $where['title'] = array('like', '%'.$keyword.'%');
			if (!empty($type))
				$where['type'] = $type;
            $total = $this->model->where($where)->count();
            $total = intval($total);
            $p = $this->getPage($total, 0, 10, 'id', 'desc');
            if ($total > 0 && $p['start'] < $total) {
                $p['data'] = $this->model->field('content', true)->where($where)->order($p['sortField'].' '.$p['sortOrder'])->limit($p['start'].','.$p['pageSize'])->select();
            }
            $this->output($p);
        }
        $this->display();
    }

    public function del()
    {
        if (!$this->isPost())
            return $this->error('非法操作');
        if (empty($_POST['ids']) || preg_match("/[^0-9,]/", $_POST['ids']))
            return $this->error('参数错误');
        $ids = explode(',', trim($_POST['ids'], ','));
        $ids = array_unique(array_filter($ids));
        if (count($ids) > 100)
            return $this->error('批量删除数量过多');

        $where['id'] = array('in', $ids);

        $res = $this->model->where($where)->delete();
        $this->success($this->model->getLastSql());
        if ($res > 0)
            $this->success('删除成功');
        else 
            $this->error('删除失败');
    } 

    protected function parseTitle($title)
    {
        if (preg_match("/color:\s*([#\w]+);/i", $title, $match)) {
            $color = $match[1];
            $title = preg_replace("/<.*?>/", "", $title);
            $title = '<span style="color:'.$color.';">'.$title.'</span>';
        }
        return $title;
    }

    public function add()
    {
        $data = array();
        $data['title'] = $this->parseTitle($_POST['title']);
        $data['content'] = Ops_Input::safeShow($_POST['content']);
		$data['type'] = $this->_type;
        if (empty($data['title']))
            $this->error('标题不能为空');
        $res = $this->model->add($data);
        if ($res)
            $this->success('添加成功');
        else
            $this->error('添加失败');
    }
    
    public function edit()
    {
        $data = $this->getData();
        if (empty($data))
            $this->error('参数错误');
        $data['cid'] = intval($data['cid']);
        $data['content'] = Ops_Input::safeShow($data['content']);
		$data['type'] = $this->_type;
        if (empty($data['title']))
            $this->error('标题不能为空');
        $data['title'] = $this->parseTitle($data['title']);
        if (empty($data['content']))
            $this->error('内容不能为空');
        if (!empty($data['id'])) {
            $data['uptime'] = time();
            $res = $this->model->save($data);
            $id = $data['id'];
        } else {
            unset($data['id']);
            $data['addtime'] = time();
            $res = $this->model->add($data);
            $id = $res;
        }
        if ($res)
            $this->ajaxReturn(array('id'=>$id), '操作成功');
        else
            $this->error('操作失败');
    }

    public function save()
    {
        if (!$this->isPost())
            return $this->error('非法操作');
        $data = $this->getData();
        $total = $fail = 0;
        $res = array();
        $time = time();
        foreach ($data as $key=>$row) {
            if (empty($row['title']) && empty($row['name']))
                continue;
            $row['title'] = $this->parseTitle($row['title']);
            if ($row['_state'] == 'added') {
                $row['addtime'] = $row['uptime'] = $time;
                $res[$key] = $this->model->add($row);
            } else {
                $row['uptime'] = $time;
                $res[$key] = $this->model->save($row);
            }
            ++ $total;
            if ($res[$key] === false) {
                ++ $fail;
            }
        }

        $return = array();
        if ($fail > 0) {
            $return['ret'] = 0;
            $return['msg'] = $total == $fail ? '失败' : '部分失败';
        } else {
            $return['ret'] = 1;
        }
        $return['res'] = $res;
        return $this->output($return);
    }

    public function detail()
    {
        $id = $this->getId();
        if (empty($id)) {
            $this->error('参数错误');
        }
        $data = $this->model->where(array('id'=>$id))->find();
        if (empty($data))
            $this->error('记录不存在');
        $this->ajaxReturn($data);
    }
}

