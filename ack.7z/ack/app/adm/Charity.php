<?php

class Adm_Action_Charity extends Adm_Action_Posts{
	
	protected $_type;

	public function _initialize()
	{
		$this->_type = parent::_getType('charity');	
		parent::_initialize();
	}

}
